# Media Server Configuration Package

This package contains all the working configurations for the media streaming server setup.

## Current Running Configuration

### Docker Containers
- **nginx-media-server**: RTMP to HLS transcoding server
- **flv-proxy-server**: RTMP to FLV proxy server

### Files Included

#### 1. nginx_production.conf
- **Purpose**: Main NGINX configuration currently used by nginx-media-server
- **Features**: 
  - RTMP input on port 1935
  - Multi-quality HLS transcoding (5 levels: source, hd720, high, mid, low)
  - HTTP server on port 80
  - FLV proxy to flv-proxy-server container
  - Adaptive streaming support

#### 2. index.html  
- **Purpose**: Web player interface for HLS and FLV streaming
- **Features**:
  - HLS.js and FLV.js integration
  - Quality switching for HLS streams
  - Direct FLV streaming support
  - Responsive design
  - Real-time stream statistics

#### 3. flv-proxy.js
- **Purpose**: Node.js server that converts RTMP to FLV
- **Port**: 8080
- **Features**:
  - RTMP to FLV conversion using FFmpeg
  - CORS support
  - Health check endpoint
  - Error handling

#### 4. package.json
- **Purpose**: Node.js dependencies for flv-proxy server
- **Dependencies**: express, cors, child_process

#### 5. Dockerfile.flv
- **Purpose**: Docker build file for flv-proxy-server
- **Base**: Node.js with FFmpeg

#### 6. docker-compose.yml
- **Purpose**: Docker Compose configuration (reference only)
- **Note**: Current setup uses individual docker run commands

#### 7. nginx_alternative.conf
- **Purpose**: Alternative NGINX configuration (backup)

## Current Setup Commands

### Start nginx-media-server:
```bash
docker run -d --name nginx-media-server --network media-network -p 80:80 -p 1935:1935 -v /tmp/nginx_fixed_final.conf:/etc/nginx/nginx.conf:ro alqutami/rtmp-hls:latest
```

### Start flv-proxy-server:
```bash
docker run -d --name flv-proxy-server --network media-network -p 8080:8080 media-server-flv-proxy
```

### Create Docker Network:
```bash
docker network create media-network
```

## Streaming URLs

### RTMP Input (for OBS):
- `rtmp://YOUR_SERVER_IP:1935/live/STREAM_KEY`

### HLS Output:
- Master playlist: `http://YOUR_SERVER_IP/hls/STREAM_KEY.m3u8`
- Specific quality: `http://YOUR_SERVER_IP/hls/STREAM_KEY_QUALITY.m3u8`

### FLV Output:
- `http://YOUR_SERVER_IP:8080/live/STREAM_KEY`

### Web Player:
- `http://YOUR_SERVER_IP/`

## Quality Levels

1. **source** - Original quality (typically 1920x1080)
2. **hd720** - 1280x720, 1920k bitrate
3. **high** - 960x540, 1024k bitrate  
4. **mid** - 720x404, 768k bitrate
5. **low** - 480x270, 256k bitrate

## Notes

- All containers must be on the same Docker network for inter-container communication
- FLV streaming bypasses nginx proxy for better performance
- HLS adaptive streaming automatically selects best quality based on network conditions
- Generated HLS segments and recordings are stored in container volumes (not persistent)

Created: Sat Jul 19 14:26:42 CST 2025
Server IP: 13.113.238.113
